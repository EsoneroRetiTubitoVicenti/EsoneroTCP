/*
 * applicationProtocol.h
 *
 *  Created on: 25 nov 2021
 *      Author: mtubi
 */

#ifndef APPLICATIONPROTOCOL_H_
#define APPLICATIONPROTOCOL_H_

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#define BUFFERSIZE 500
#define MAX_NUM 4
#define LOCALHOST "127.0.0.1"
#define PORT 27015

#endif /* APPLICATIONPROTOCOL_H_ */
