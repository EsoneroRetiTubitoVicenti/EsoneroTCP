/*
 * main.c
 *
 *  Created on: 21 nov 2021
 *      Author: mtubi
 */

#include "clientFunctions.h"
#include <stdlib.h>

int main(){
	client();
	system("Pause");
	return 0;
}
