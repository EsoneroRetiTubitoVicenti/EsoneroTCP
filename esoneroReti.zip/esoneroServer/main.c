/*
 * main.c
 *
 *  Created on: 21 nov 2021
 *      Author: mtubi
 */


#include "serverFunctions.h"
#include <stdlib.h>

int main(){
	server();
	system("pause");
}
